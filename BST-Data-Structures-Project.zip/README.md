# Binary Search Tree (BST) Implementation

## Overview
This project implements a **Binary Search Tree (BST)** in Python for the **DCOMP320: Data Structures and Algorithm** course.  
It demonstrates the core operations of **insertion**, **deletion**, and **search**, as well as **inorder traversal** to display the tree's contents in sorted order.

---

## 📘 Features
- Insert integer nodes into a Binary Search Tree.
- Delete nodes while maintaining BST structure.
- Search for a specific node.
- Display tree contents using inorder traversal.
- Read commands from an input file (`input.txt`) and write results to an output file (`output.txt`).

---

## 📁 Project Structure

```
BST-Data-Structures-Project/
│
├── bst.py              # Main Python script for BST operations
├── input.txt           # Input file with operations
├── output.txt          # Output file with results
├── report/
│   └── BST_Report.docx # Detailed project report
└── README.md           # This documentation
```

---

## ⚙️ How to Run

1. Ensure you have **Python 3.x** installed.  
2. Clone or download this repository.
3. Run the following command in your terminal or IDE:

```bash
python bst.py
```

4. Check the generated `output.txt` file for results.

---

## 🧪 Example

### input.txt
```
INSERT 50
INSERT 30
INSERT 70
INSERT 20
INSERT 40
INSERT 60
INSERT 80
SEARCH 40
DELETE 30
INORDER
```

### output.txt
```
SEARCH 40: FOUND
INORDER TRAVERSAL AFTER OPERATIONS:
20 40 50 60 70 80
```

---

## 🧠 Learning Objectives
- Understand the **Binary Search Tree** data structure.
- Implement **recursive algorithms** for insert, delete, and search.
- Handle **file I/O** operations in Python.
- Demonstrate good **code structure** and documentation.

---

## 👨‍💻 Author
**Buhari Bangura**  
Data Structures and Algorithms – DCOMP320

---

## 📚 References
- Knuth, D. E. (1997). *The Art of Computer Programming, Volume 1: Fundamental Algorithms.* Addison-Wesley.  
- Goodrich, M. T., Tamassia, R., & Goldwasser, M. H. (2014). *Data Structures and Algorithms in Python.* Wiley.  
- Weisstein, E. W. (n.d.). Binary Search Tree. *MathWorld—A Wolfram Web Resource.*
