class Node:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None


class BST:
    def __init__(self):
        self.root = None

    def insert(self, value):
        if self.root is None:
            self.root = Node(value)
        else:
            self._insert(self.root, value)

    def _insert(self, node, value):
        if value < node.data:
            if node.left is None:
                node.left = Node(value)
            else:
                self._insert(node.left, value)
        elif value > node.data:
            if node.right is None:
                node.right = Node(value)
            else:
                self._insert(node.right, value)

    def search(self, node, value):
        if node is None:
            return None
        elif node.data == value:
            return node
        elif value < node.data:
            return self.search(node.left, value)
        else:
            return self.search(node.right, value)

    def delete(self, node, value):
        if node is None:
            return node
        if value < node.data:
            node.left = self.delete(node.left, value)
        elif value > node.data:
            node.right = self.delete(node.right, value)
        else:
            if node.left is None:
                return node.right
            elif node.right is None:
                return node.left
            temp = self._min_value_node(node.right)
            node.data = temp.data
            node.right = self.delete(node.right, temp.data)
        return node

    def _min_value_node(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def inorder(self, node):
        result = []
        if node:
            result += self.inorder(node.left)
            result.append(node.data)
            result += self.inorder(node.right)
        return result


def process_files(input_file, output_file):
    bst = BST()
    with open(input_file, 'r') as f:
        lines = f.readlines()

    with open(output_file, 'w') as f:
        for line in lines:
            parts = line.strip().split()
            if len(parts) == 0:
                continue
            cmd = parts[0].upper()
            if cmd == 'INSERT' and len(parts) == 2:
                bst.insert(int(parts[1]))
            elif cmd == 'DELETE' and len(parts) == 2:
                bst.root = bst.delete(bst.root, int(parts[1]))
            elif cmd == 'SEARCH' and len(parts) == 2:
                node = bst.search(bst.root, int(parts[1]))
                if node:
                    f.write(f"SEARCH {parts[1]}: FOUND\n")
                else:
                    f.write(f"SEARCH {parts[1]}: NOT FOUND\n")
            elif cmd == 'INORDER':
                traversal = bst.inorder(bst.root)
                f.write('INORDER TRAVERSAL AFTER OPERATIONS:\n')
                f.write(' '.join(map(str, traversal)) + '\n')

    print("Processing completed. Results written to", output_file)


if __name__ == "__main__":
    process_files('input.txt', 'output.txt')
